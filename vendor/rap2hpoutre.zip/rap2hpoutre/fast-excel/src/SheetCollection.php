<?php

namespace Rap2hpoutre\FastExcel;

use Illuminate\Support\Collection;

class SheetCollection extends Collection
{
}
