<?php

namespace Box\Spout\Reader\ODS;

/**
 * Class ReaderOptions
 * This class is used to customize the reader's behavior
 *
 * @package Box\Spout\Reader\ODS
 */
class ReaderOptions extends \Box\Spout\Reader\Common\ReaderOptions
{
    // No extra options
}
